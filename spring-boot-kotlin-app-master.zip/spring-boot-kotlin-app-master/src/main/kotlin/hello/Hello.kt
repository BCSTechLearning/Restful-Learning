package hello

data class Hello(val message: String)
