package com.galleryapp.galleryapp.model

import java.time.LocalDate

class Anime(var animeTitle: String?, var datePublish: LocalDate?, var protagonistName: String?)
